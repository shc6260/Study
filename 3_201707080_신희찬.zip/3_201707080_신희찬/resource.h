//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// My3201707080.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_My3201707080TYPE            130
#define IDB_BITMAP1                     310
#define IDB_BITMAP2                     311
#define IDB_BITMAP3                     312
#define ID_LINE                         32771
#define ID_POLYGON                      32773
#define ID_CROSS                        32777
#define ID_CIRCLE                       32780
#define ID_32783                        32783
#define ID_32784                        32784
#define ID_RED                          32785
#define ID_BLUE                         32786
#define ID_RECT                         32789
#define ID_32791                        32791
#define ID_32792                        32792
#define ID_YELLOW                       32793
#define ID_BLACK                        32794
#define ID_BDIAGONAL                    32795
#define ID_32796                        32796
#define ID_                             32797
#define ID_Horizon                      32798
#define ID_vertical                     32799
#define ID_Vertical                     32800
#define ID_32801                        32801
#define ID_FDIAGONAL                    32802
#define ID_32803                        32803
#define ID_HS_DIAGCROSS                 32804
#define ID_CAR                          32805
#define ID_CANDY                        32806
#define ID_32807                        32807
#define ID_YOUTUBE                      32808
#define ID_CLEAR                        32809

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        313
#define _APS_NEXT_COMMAND_VALUE         32810
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
