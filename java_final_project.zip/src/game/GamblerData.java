package game;

public class GamblerData {
	String name=null;   
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getChip() {
		return chip;
	}
	public void setChip(int chip) {
		this.chip = chip;
	}
	public int getWin() {
		return win;
	}
	public void setWin(int win) {
		this.win = win;
	}
	int chip = 0;
	int g_num = 0;
	public int getG_num() {
		return g_num;
	}
	public void setG_num(int g_num) {
		this.g_num = g_num;
	}
	int win = 0;
}
