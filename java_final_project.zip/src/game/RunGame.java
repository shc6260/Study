package game;

import java.util.Random;

public class RunGame {

	GameData[] gamedata;
	GamblerData[] gambler;
	GameData g1_gamedata;
	GamblerData g1_GamblerData;
	GameData g2_gamedata;
	GamblerData g2_GamblerData;
	int encard = 0;
	int batchip=0;
	int g1_batchip=0;
	int g2_batchip=0;
	public RunGame()
	{
		g1_GamblerData = new GamblerData();
		g2_GamblerData = new GamblerData();
		g1_gamedata = new GameData();
		g2_gamedata = new GameData();
		gamedata = new GameData[20];
		gambler = new GamblerData[2];
		for(int i = 0 ; i < 2 ;i++)
		{
			for(int j = 0 ; j < 10 ; j++)
			{
				gamedata[j] = new GameData();
				gamedata[j].setCardnum(j+1);
				gamedata[j].setCardenable(true);
				gamedata[j].setIcon("img/"+(j+1)+".png");
			}
			gambler[i] = new GamblerData();
			gambler[i].setChip(20);
			gambler[i].setWin(0);
		}
		batchip = 0;
	}
	
	public void ReGame()
	{
		for(int i = 0 ; i < 2 ;i++)
		{
			for(int j = 0 ; j < 10 ; j++)
			{
				gamedata[j].setCardnum(j+1);
				gamedata[j].setCardenable(true);
				gamedata[j].setIcon("img/"+(j+1)+".png");
			}
			gambler[i].setChip(20);
			gambler[i].setWin(0);
		}
		batchip = 0;
	}
	

	public void MatchCard()
	{
		Random random = new Random();
		int n1;
		int n2;
		while(true)
		{
			n1 = random.nextInt(20);//���̸� 1 ī��
			n2 = random.nextInt(20);//���̸� 2 ī��
			if(encard == 10)
			{
				ShuffleCard();
			}
			else
			{
				if(n1 != n2)
				{
					if(gamedata[n1].isCardenable() ||gamedata[n2].isCardenable() )
					{
						gambler[0].setG_num(gamedata[n1].getCardnum());
						gambler[1].setG_num(gamedata[n2].getCardnum());
						gamedata[n1].setCardenable(false);
						gamedata[n2].setCardenable(false);
						if(gambler[0].getG_num() == gambler[1].getG_num())
						{
							encard++;
							break;
						}
						else if(gambler[0].getG_num() > gambler[1].getG_num())//���̸� 1 ��
						{
							int tempchip = gambler[0].getChip();
							tempchip += batchip;
							gambler[0].setChip(tempchip);
							gambler[0].setWin(gambler[0].getWin()+1);
							encard++;
							batchip = 0;
							break;
						}
						else
						{
							int tempchip = gambler[1].getChip();
							tempchip += batchip;
							gambler[1].setChip(tempchip);
							gambler[1].setWin(gambler[1].getWin()+1);
							encard++;
							batchip = 0;
							break;
						}
						
					}
				}
			}
			
		}
		g1_gamedata = gamedata[n1];
		g1_GamblerData =gambler[0];
		g2_gamedata = gamedata[n2];
		g2_GamblerData =gambler[1];
		
	}
	public GameData getG1_gamedata() {
		return g1_gamedata;
	}

	public void setG1_gamedata(GameData g1_gamedata) {
		this.g1_gamedata = g1_gamedata;
	}

	public GamblerData getG1_GamblerData() {
		return g1_GamblerData;
	}

	public void setG1_GamblerData(GamblerData g1_GamblerData) {
		this.g1_GamblerData = g1_GamblerData;
	}

	public GameData getG2_gamedata() {
		return g2_gamedata;
	}

	public void setG2_gamedata(GameData g2_gamedata) {
		this.g2_gamedata = g2_gamedata;
	}

	public GamblerData getG2_GamblerData() {
		return g2_GamblerData;
	}

	public void setG2_GamblerData(GamblerData g2_GamblerData) {
		this.g2_GamblerData = g2_GamblerData;
	}

	public int getBatchip() {
		return batchip;
	}

	public void setBatchip(int batchip) {
		this.batchip = batchip;
	}

	public int getG1_batchip() {
		return g1_batchip;
	}

	public void setG1_batchip(int g1_batchip) {
		this.g1_batchip = g1_batchip;
	}

	public int getG2_batchip() {
		return g2_batchip;
	}

	public void setG2_batchip(int g2_batchip) {
		this.g2_batchip = g2_batchip;
	}

	public void ShuffleCard()
	{
		for(int i=0 ; i<20 ; i++)
		{
			gamedata[i].setCardenable(true);
		}
		encard = 0;
	}
	
	public void g1_AllIn()
	{
		batchip += gambler[0].getChip();
		g1_batchip = gambler[0].getChip();
		gambler[0].setChip(0);
	}
	public void g1_Call()
	{
		if (gambler[0].getChip() <= g2_batchip)
		{
			g1_AllIn();
		}
		else
		{
			gambler[0].setChip(gambler[0].getChip()-g2_batchip);
			batchip += g2_batchip;
		}
	}
	public void g1_Batting()
	{
		gambler[0].setChip(gambler[0].getChip()-1);
		batchip += 1;
	}
	public void g1_Die()
	{
		gambler[1].setChip(gambler[1].getChip()+batchip);
	}
	public void g2_AllIn()
	{
		batchip += gambler[1].getChip();
		g2_batchip = gambler[1].getChip();
		gambler[1].setChip(0);
	}
	public void g2_Call()
	{
		if (gambler[1].getChip() <= g1_batchip)
		{
			g1_AllIn();
		}
		else
		{
			gambler[1].setChip(gambler[1].getChip()-g1_batchip);
			batchip += g1_batchip;
		}
	}
	public void g2_Batting()
	{
		gambler[1].setChip(gambler[1].getChip()-1);
		batchip += 1;
	}
	public void g2_Die()
	{
		gambler[0].setChip(gambler[0].getChip()+batchip);
	}
	
	public int resultgame()
	{
		if(gambler[0].getChip() <= 0)
		{
			return 1; // �÷��̾� 1 ��
		}
		else if(gambler[1].getChip() <= 0)
		{
			return 2; // �÷��̾� 2 ��
		}
		return 0; // �����ȳ���
	}
	public void g1_id_set(String name)
	{
		gambler[0].setName(name);
	}
	public void g2_id_set(String name)
	{
		gambler[1].setName(name);
	}
	public int getcardnum1()
	{
		return g1_gamedata.cardnum;
	}
	public int getcardnum2()
	{
		return g2_gamedata.cardnum;
	}
}
