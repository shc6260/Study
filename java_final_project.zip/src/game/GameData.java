package game;

import javax.swing.ImageIcon;

public class GameData {
	int cardnum = 0;
	boolean cardenable =false;
	ImageIcon icon = null;
	public ImageIcon getIcon() {
		return icon;
	}
	public void setIcon(String string) {
		this.icon = new ImageIcon(string);
	}
	public int getCardnum() {
		return cardnum;
	}
	public void setCardnum(int cardnum) {
		this.cardnum = cardnum;
	}
	public boolean isCardenable() {
		return cardenable;
	}
	public void setCardenable(boolean cardenable) {
		this.cardenable = cardenable;
	}
}
