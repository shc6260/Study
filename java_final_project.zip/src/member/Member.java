package member;

public class Member {

	String m_id;
	String m_pass;
	int m_win;
	String m_name;
	public String getM_id() {
		return m_id;
	}
	public void setM_id(String m_id) {
		this.m_id = m_id;
	}
	public String getM_pass() {
		return m_pass;
	}
	public void setM_pass(String m_pass) {
		this.m_pass = m_pass;
	}
	public int getM_win() {
		return m_win;
	}
	public void setM_win(int m_win) {
		this.m_win = m_win;
	}
	public String getM_name() {
		return m_name;
	}
	public void setM_name(String m_name) {
		this.m_name = m_name;
	}
}
