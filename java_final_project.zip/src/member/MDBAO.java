package member;

import java.sql.*;

public class MDBAO {
	int i = 0;
	private Connection conn = null;
	private PreparedStatement pstmt = null;
	private ResultSet rs = null;
	
	public MDBAO()
	{
		try{
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			String jdbcUrl = "jdbc:mysql://localhost:3306/javatest?characterEncoding=UTF-8&serverTimezone=UTC";
			String dbId="javaid";
			String dbPass="javapass";
			conn = DriverManager.getConnection(jdbcUrl, dbId, dbPass);
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			
		}
	}
	
	public int login(String mem_ID, String mem_Pass)
	{
		String SQL ="SELECT m_pass  FROM member_tb WHERE m_id = ?";
		try
		{
			pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1,mem_ID);
			rs = pstmt.executeQuery();
			if(rs.next())
			{
				if(rs.getString("m_pass").equals(mem_Pass))
				{
				
					return 1;
					
				}
				else
				{
					return 0;
				}
			}
			
			return -1;
		}catch(Exception e)
		{
			return -2;
		}
	}
	public int join(String id, String pass, String name) {

	
		String SQL = "INSERT INTO member_tb(m_id,m_pass,m_win,m_name) VALUES (?,?,?,?)";

		try {

			pstmt = conn.prepareStatement(SQL);
			
			pstmt.setString(1,id);
			
			pstmt.setString(2,pass);
			
			pstmt.setInt(3,0);

			pstmt.setString(4,name);
			
			

			return pstmt.executeUpdate();

		} catch (Exception e) {

			e.printStackTrace();

		}

		return -1; // DB ����

	}
	
	public int upwin(String id) {
		String SQL = "UPDATE member_tb SET m_win=m_win+1 WHERE m_id";
		

		try {

			pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1,id);
			return pstmt.executeUpdate();

		} catch (Exception e) {

			e.printStackTrace();

		}

		return -1; // DB ����

	}
	public Member Searchmember(String m_id){ 
		Member member = new Member();
		PreparedStatement pstmt2 = null;
		ResultSet rs2 = null;
		String SQL2 = "SELECT * FROM member_tb WHERE m_id = ? ";
		try {

			pstmt2 = conn.prepareStatement(SQL2);
			pstmt2.setString(1,m_id);

			rs2 = pstmt2.executeQuery();
			rs2.next();
			member.setM_name(rs2.getString("m_name"));
			member.setM_id(rs2.getString("m_id"));
			member.setM_pass(rs2.getString("m_pass"));
			member.setM_win(rs2.getInt("m_win"));
			
		} catch (Exception e) {

			e.printStackTrace();

		}

		return member; 

	}

}
