package server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import game.RunGame;


public class ChatServer {
		
		ServerSocket ss; // ���� ����
		Socket s;// Ŭ���̾�Ʈ ���� ����
		ArrayList<Thread> aList;
		int i = 0 ; //�ο���
		RunGame rungame;
		
		
	public ChatServer()
	{
		aList = new ArrayList<Thread>();
		System.out.println("ä�� ���� ����");
		rungame= new RunGame();
		
		
	}

		
	public void giveAndTake()
	{
		try 
		{
			ss = new ServerSocket(7777);
			ss.setReuseAddress(true);
			while(true)
			{
				s= ss.accept();
				ServerSocketThread sst = new ServerSocketThread(this, s);
				if(i <= 2)
				{
					addClient(sst);
					sst.start();
				}
				
			}
		} catch (IOException e) {
			
		}
		
		
	}
	public synchronized void addClient(Thread t)
	{
		aList.add(t);
		System.out.println("Ŭ���̾�Ʈ 1�� ����, ��" + aList.size() + "��");
	}
	
	
	public synchronized void removeClient(Thread t)
	{
		aList.remove(t);
		System.out.println("Ŭ���̾�Ʈ 1�� ����, ��" + aList.size() + "��");
	}
	
	public synchronized void broadCasting(String str)
	{
		for (int i = 0; i < aList.size(); i++) {
			ServerSocketThread sst = (ServerSocketThread)aList.get(i);
			sst.sendMessage(str);
		}
	}
	
	public synchronized void sendCard(Thread t)
	{
		ServerSocketThread sst = (ServerSocketThread)aList.get(0);
		sst.sendMessage("1");
		//sst = (ServerSocketThread)aList.get(1);
		//sst.sendMessage("2");
	}
}
