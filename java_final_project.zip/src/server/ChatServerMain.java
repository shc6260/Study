package server;


public class ChatServerMain {

	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ChatServer cs = new ChatServer();
		cs.giveAndTake();
	}

}
