package client;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import javax.swing.*;
import game.RunGame;



public class ClientGUI extends JPanel implements Runnable, ActionListener {
	Socket s;
	JTextArea ta;
	JTextField tf;
	PrintWriter pw;
	boolean index = false;
	BufferedReader br;
	JPanel menu, view, chat, menu_1,menu_2;
	JButton g_start, g_stop, g_call, g_allin, g_batting ,g_die;
	JLabel g1img, g2img;
	ImageIcon g1icon = new ImageIcon("img/card.png");
	ImageIcon g2icon = new ImageIcon("img/card.png");
	public ClientGUI(String ip, int port) {
		initLayout();
		System.out.println(this.getClass().getName() + "1. Start =>");
		try {
			s = new Socket(ip,port);
		} catch (Exception e) {
			System.out.println("�������� ������ ���� ���� ���� ����!");
		}
		
		System.out.println(this.getClass().getName() + "2. Socket =>");
	}
	
	public void initLayout()
	{
		setLayout(new GridLayout(1,3));
		//�޴�
		menu = new JPanel();
		menu.setLayout(new GridLayout(2,1));
		//���� ���� �� ����
		menu_1 = new JPanel();
		g_start = new JButton("���ӽ���");
		g_start.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				menu.add(menu_2);
				
				
			}
		});
		g_stop = new JButton("��������");
		g_stop.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		menu_1.add(g_start);
		menu_1.add(g_stop);
		//���� ����
		menu_2 = new JPanel();
		g_call = new JButton("��");
		g_batting = new JButton("����");
		g_allin = new JButton("����");
		g_die = new JButton("����");
		g_call.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				
			}
		});
		g_batting.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		g_allin.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		g_die.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		menu_2.add(g_call);
		menu_2.add(g_batting);
		menu_2.add(g_allin);
		menu_2.add(g_die);
		menu.add(menu_1);
		//�޴�
		
		//����
		view = new JPanel();
		view.setLayout(new GridLayout(2,1));
		view.setBackground(Color.black);
		g1img = new JLabel(g1icon);
		g2img = new JLabel(g2icon);
		view.add(g1img);
		view.add(g2img);
		//����
		
		//ü��
		chat = new JPanel();
		chat.setLayout(new BorderLayout());
		ta = new JTextArea(20, 50);
		tf = new JTextField(50);
		chat.add(ta,"Center");
		chat.add(tf,"South");
		tf.addActionListener(this);
		ta.setEditable(false);
		tf.requestFocus();
		//ü��
		add(menu);
		add(view);
		add(chat);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		tf.requestFocus();
		String str = tf.getText();
		pw.println(str);
		tf.setText("");

	}

	public void giveAndTake()
	{
		System.out.println(this.getClass().getName() + "3. InputOutput =>");
		try {
			pw = new PrintWriter(s.getOutputStream(), true);
			br = new BufferedReader(new InputStreamReader(s.getInputStream()));
			Thread t1 = new Thread(this);
			t1.start();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void run() {
		System.out.println(this.getClass().getName() + "4. run =>");
		String line = null;
		try {
			while((line = br.readLine())!=null)
			{
				if(index)
				{
					ta.append(line+"\n");
				}
				else
				{
					g1icon = new ImageIcon("img/1.png");
					initLayout();
					index= true;
				}
				
				
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				s.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}
	

}
