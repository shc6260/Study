package client;

import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.*;
import java.beans.EventHandler;
import member.MDBAO;
import javax.swing.*;




public class ClientMainFrame extends JFrame implements Action{
	JButton btnlogin, btnsignup, btnsignupok;
	JPanel panelogin, panesignup, pane1, pane3, pane2;
	JTextField id, signupid, signuppass, signupname, pass;
	Container c;
	public ClientMainFrame()
	{
		setTitle("Client Chatting Frame");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		c = getContentPane();
		c.setLayout(new GridLayout(1, 1));
		
		// �α��� ��
		panelogin = new JPanel();
		panelogin.setLayout(new FlowLayout());
		id = new JTextField(37);
		pass = new JTextField(35);
		panelogin.add(new JLabel("ID : "));
		panelogin.add(id);
		panelogin.add(new JLabel("PASS : "));
		panelogin.add(pass);
		btnlogin = new JButton("�α���");
		btnlogin.addActionListener(this);
		btnsignup = new JButton("ȸ������");
		btnsignup.addActionListener(this);
		panelogin.add(btnlogin);
		panelogin.add(btnsignup);
		// �α��� ��
		
		//ȸ������ ��
		panesignup = new JPanel();
		panesignup.setLayout(new FlowLayout());
		signupid = new JTextField(20);
		signuppass = new JTextField(20);
		signupname = new JTextField(20);
		panesignup.add(new JLabel("ID : "));
		panesignup.add(signupid);
		panesignup.add(new JLabel("PASS : "));
		panesignup.add(signuppass);
		panesignup.add(new JLabel("name : "));
		panesignup.add(signupname);
		btnsignupok =new JButton("ȸ������");
		btnsignupok.addActionListener(this);
		panesignup.add(btnsignupok);
		//ȸ������ ��
		
		
		pane1 = new JPanel();	
		pane1.setLayout(new GridLayout(2, 1));
		
		pane1.add(panelogin);
		pane3 = new JPanel();
		pane3.setBackground(Color.gray);
		pane1.add(pane3);
		pane2 = new JPanel();
		pane2.setBackground(Color.black);
		pane2.add(new JLabel("ȸ������ �Ϸ�"));
		
		c.add(pane1);
		//c.remove(pane1);
		//c.add(pane2);
		
		
		
		
		setBounds(700, 50, 900, 900);
		setVisible(true);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new ClientMainFrame();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		MDBAO mdbao = new MDBAO();
		if(e.getSource() == btnlogin)
		{
			if(mdbao.login(id.getText(),pass.getText()) == 1)
			{
				c.remove(pane1);
				ClientGUI client = new ClientGUI("127.0.0.1",7777);
				client.giveAndTake();
				c.add(client);
				revalidate();
				
			}
		}
		else if(e.getSource() == btnsignup)
		{
			pane1.remove(pane3);
			pane1.add(panesignup);
			revalidate();
		}
		else if(e.getSource() == btnsignupok)
		{
			int result = mdbao.join(signupid.getText(),signuppass.getText(),signupname.getText());
			if(result == -1)
			{
				pane1.remove(panesignup);
				pane1.add(pane3);
				revalidate();
			}
			else
			{
				pane1.remove(panesignup);
				pane1.add(pane2);
				revalidate();
			}
		}
		
	}

	@Override
	public Object getValue(String key) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void putValue(String key, Object value) {
		// TODO Auto-generated method stub
		
	}

}
