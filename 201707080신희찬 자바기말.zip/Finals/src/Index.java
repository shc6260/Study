import init_screen.LoginScreen;

public class Index {

	public static void main(String[] args) {
		new LoginScreen();

	}

}
