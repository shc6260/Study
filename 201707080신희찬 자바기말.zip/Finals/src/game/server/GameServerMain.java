package game.server;

public class GameServerMain {

	public static void main(String[] args) {
		GameServer cs = new GameServer();
		cs.giveAndTake();
	}

}


